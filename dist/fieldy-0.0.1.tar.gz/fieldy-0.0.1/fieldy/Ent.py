class Ent:
  def __init__(self):
    pass