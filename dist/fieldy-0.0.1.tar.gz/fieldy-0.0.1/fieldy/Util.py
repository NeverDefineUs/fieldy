def get_base_types():
  return ["string", "integer", "float", "boolean"]